
For adding custom sprites, use mindustry pallete, along infinity pallete spotted in this branch

Considering im running out of Source moddingn't stuff ideas, at one point i might shift this into source version, and that will probably end up before b-[idk] (since scripting is a thing). Mod may or may not split up, for some reason

People who know scripting, i would like to help me implement a l o t o f s t u f f

 And no, i neither have time nor the nerves to study scripting all day... LIKE SERIOUSLY I NEED HELP

CHANGELOG
 
 -Arc MK2, internally called "Edison"
 
 -Way to craft critter boxes, their factories are currently broken

-Toughitinum walls

-Metaphor in it's young phase

-More sprites

-Relatively working Multidimensional portal (not how it was planned, i gotta leave it of sorts)

-Matrix update

-Pilotable eradicator

-Infiar wall mitosis

UPCOMING

-More sprites

-Informational texts

-Plastanium ore

-Divinity but i did not uploaded it because its quite literally broken

-Mapping shenaniganning

-3.5 "Tribal" expansion

--Drills

--Turrets

--Dirium, Uranium, Iron and Steel

--Lava

--Some other forgotten technology
